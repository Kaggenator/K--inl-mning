﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Line kö = new Line();

            kö.Enqueue(1);
            kö.Enqueue(2);
            kö.Enqueue(3);
            kö.Enqueue(4);
            kö.Enqueue(5);
            Console.WriteLine("First: " + kö.Peek());
            Console.WriteLine("Elements: " + kö.Count);
            Console.WriteLine();

            kö.Dequeue();
            Console.WriteLine("First: " + kö.Peek());
            Console.WriteLine("Elements: " + kö.Count);
            Console.WriteLine();

            kö.Dequeue();
            Console.WriteLine("First: " + kö.Peek());
            Console.WriteLine("Elements: " + kö.Count);
            Console.WriteLine();

            kö.Enqueue(6);
            Console.WriteLine("First: " + kö.Peek());
            Console.WriteLine("Elements: " + kö.Count);
            Console.WriteLine();

            kö.Clear();
            Console.WriteLine("Elements: " + kö.Count);
        }
    }
}
