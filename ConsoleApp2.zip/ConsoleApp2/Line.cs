﻿namespace ConsoleApp2
{
    class Line
    {

        private int[] kö;
        private int count = 0;

        public int Count
        {
            get { return count; }    
        }

        public int this[int i]
        {
            get { return kö[i]; }
            set { kö[i] = value; }
        }

        public Line()
        {
            kö = new int[10];
        }

        public Line(int size)
        {
            kö = new int[size];
        }

        public void Enqueue(int value)
        {
            if (kö.Length == count)
                ReSize((int)(count * 1.3));

            kö[count] = value;
            count++;
        }

        public int Dequeue()
        {
            kö[0] = kö[1];
            kö[1] = kö[2];
            kö[2] = kö[3];
            kö[3] = kö[4];
            kö[4] = kö[5];
            count--;

            if (count == kö.Length / 2 && kö.Length > 100)
                ReSize((int)(count * 1.3));

            return kö[count];
        }

        public int Peek()
        {
            return kö[count - count];
        }

        private void ReSize(int size)
        {
            int[] temp = kö;

            kö = new int[size];

            for (int i = 0; i < count; i++)
            {
                kö[i] = temp[i];
            }
        }

        public void Clear()
        {
            count = 0;
            kö = new int[10];
        }

    }
}
